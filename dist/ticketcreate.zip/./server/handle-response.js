exports = {
  handleFreshdeskResponse: function(data) {
    console.log("Freshdesk Response:", data);
  },
  
  handleError: function(error) {
    console.error("Error:", error);
  }
};
